/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia.tsoulos;

import java.awt.FlowLayout;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class StudentFrame extends JFrame{
    private ArrayList<Student>mstudents = new ArrayList<Student>();//dynamictables and list's statement
    private ArrayList<Lesson> mlessons = new ArrayList<Lesson>();
    private ArrayList<Enroll> menrolls = new ArrayList<Enroll>();
    private JMenuBar menubar;
    private JMenu filemenu,filestudent,filelesson;
    private JMenuItem load,save,exit,newstudent,lessonenrollment,studentappearance,studentdeletion,newlesson,performanceappearance,semesterselection,lessondeletion;
    private JButton bt;
    private JTextArea area;
    public StudentFrame(String title){
        super(title);
        setSize(600,450);
        setResizable(false);//the size is unchancgeable
        setLayout(new FlowLayout());
        area=new JTextArea();
        add(area);//kanei add kai to prosthetei sto parathyro
        menubar=new JMenuBar();//einai h grammh pou anagrafontai ta file lesson kai student
        setJMenuBar(menubar);
        filemenu= new JMenu("FILE");
        filestudent=new JMenu("STUDENT");
        filelesson=new JMenu("LESSON");
        load=new JMenuItem("LOAD");
        load.addActionListener(new ActionListener()
        {
             @Override
            public void actionPerformed(ActionEvent ae)
            {
               JFileChooser chooser=new JFileChooser();
               int returnVal = chooser.showOpenDialog(StudentFrame.this);//ANOIGEI ETOIMO PARATHYRO THS JAVA
               if (returnVal == JFileChooser.APPROVE_OPTION)//ΔΕΙΧΝΕΙ ΑΝ ΕΠΙΛΑΞΑΜΕ ΤΟ CANCEL η ΤΟ SAVE
                {
                    try {
                    String filename=chooser.getSelectedFile().getAbsolutePath();//getAbsolutePath()->save the file in the exactly location automatically
                    FileReader rw=new FileReader(filename);//ANOIGEI KAI DIABAZEI TO ARXEIO
                    Scanner in=new Scanner(rw);//EINAI OUSIASTIKA ENA STREAM..DEN EINAI OLO YLOPOIHMENO
                    mstudents=new ArrayList<Student>();//ADEIAZEI TH LISTA KAI DHMIOURGEI KAINOYRGIA
                    while(in.hasNextLine())//EINAI SYNARTHSH POY PERIEXEI KLASEIS SCANNER..
                    {
                     String line=in.nextLine();
                     String[] parts=line.split(",");
                     mstudents.add(new Student(parts[0],parts[1],Integer.parseInt(parts[2]),Integer.parseInt(parts[3])));
                   }
                      } catch (IOException ex) 
                         {
                } 
             }
                System.out.println("pressed load");
            }
        });
         save=new JMenuItem("SAVE");
           save.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent ae)
            {
               JFileChooser chooser=new JFileChooser();
               int returnVal = chooser.showSaveDialog(StudentFrame.this);
               if (returnVal == JFileChooser.APPROVE_OPTION) 
              {
          
                 try {
                 String filename=chooser.getSelectedFile().getAbsolutePath();//
                 FileWriter fw=null;
                 fw = new FileWriter(filename);
                 PrintWriter pw=new PrintWriter(fw);
                 for(Student x:mstudents)
                 {
                  pw.println(""+x);
                 }
                 for(Lesson x:mlessons)
                 {
                  pw.println(""+x);
                 }
                 for(Enroll x:menrolls)
                 {
                  pw.println(""+x);
                 }
                 fw.close();
                   } catch (IOException ex) {
                        JOptionPane.showMessageDialog(null,"ERROR");
             } 
      }
                System.out.println("pressed save");
            }
        });
        exit=new JMenuItem("EXIT");
        exit.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                JOptionPane.showMessageDialog(null,"selected item"+ae.getActionCommand());//getActionCommand returns alphanumeric from the pressed button
                System.out.println("pressed EXIT");
                if(ae.getActionCommand().equals("EXIT")) System.exit(0);
           }
        });
        filemenu.add(load);
        filemenu.add(save);
        filemenu.add(exit);
        menubar.add(filemenu);
        
        newstudent=new JMenuItem("NEW STUDENT");
        newstudent.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                firstinputdialog fs=new firstinputdialog(StudentFrame.this);
                System.out.println("pressed NEW STUDENT");
                Student mystudent=fs.getStudent();
                if(mystudent.getName().length()!=0 || mystudent.getLastName().length()!=0 || mystudent.getStudid()!=0)
                  {
                         boolean found=false;
                          for(Student a : mstudents)
                          {
                              if (a.getStudid()== mystudent.getStudid())
                                      {
                                          found=true;
                                          break;
                                      }
                          }
                          if(found)
                          JOptionPane.showMessageDialog(null,"Already there");
                          else 
                             mstudents.add(mystudent); 
                           String total="";
                         for (Student a:mstudents)
                          {
                          total+=a+"\n";
                          }                                    
                         area.setText(total);
                     }
                  else
                      JOptionPane.showMessageDialog(null,"Empty area!");
            }
        });
       lessonenrollment=new JMenuItem("LESSON ENROLLMENT");
       lessonenrollment.addActionListener(new ActionListener()
       {
           @Override
          public void actionPerformed(ActionEvent ae)
            {
                firstinputdialogenrolls en=new firstinputdialogenrolls(StudentFrame.this);
                 Enroll myenroll=en.getEnroll();
              if(myenroll.getStudentcode()!=0 || myenroll.getCoursecode()!=0 || myenroll.getStudgrade()!=0)//ελεγχει το μηκος των πεδίων,και εξασφαλιζει οτι εχω βάλει τιμε΄ς στα πεδία
                  {
                          boolean found=false;
                          boolean found2=false;
                          boolean found3=false;
                          for(Enroll x:menrolls)//διατρέχουμε την λίστα mentrolls
                          {
                              if(x.getStudentcode()==myenroll.getStudentcode()&& x.getCoursecode()==myenroll.getCoursecode())//ελεγχει αν υπαρχει ήδη μια εγγραφή ωστε να μην την ξαναβάλει
                              {found2=true;
                              break;
                              }
                          }
                          if(found2){     //εμφανίζει το μήνυμα οτι η εγγραφή υπάρχει ήδη αν το found2 γίνει true
                              JOptionPane.showMessageDialog(null,"Already there");
                          }
                          else //αν δεν υπάρχει εγγραφή ελέγχει τις λίστες των μαθητών
                               //και συγκεκριμένα τα πεδία studid και lessoncode
                          {
                          for(Student a : mstudents)
                          {
                              if (a.getStudid()== myenroll.getStudentcode())//BLEPEI AN YPARXEI HDH H EGGRAFH WSTE NA MHN TO KSANABALEI
                                      {
                                          found=true;
                                          break;
                                      }
                          }
                           for(Lesson l:mlessons)
                           {
                               if (l.getLescode()== myenroll.getCoursecode())
                                      {
                                          found3=true;
                                          break;
                                      }
                         }
                         if(found && found3)//αν υπάρχουν οι μαθητές και τα μαθήματα στις αντίστοιχες λίστες τότε βάζει στην λίστα menrolls την συγκεκριμένη εγγραφή
                         {
                             menrolls.add(myenroll);
                         }
                         else  { // αλλιώς αν δεν υπάρχουν οι εγγραφές στις λίστες εμφανίζει μήνυμα λάθους
                             JOptionPane.showMessageDialog(null,"may be a mistake");}
                             String total="";
                          for(Enroll l:menrolls)//διατρέχει την λίστα menrolls καιεκτυπώνει τις εγγραφές
                              total+=l+"\n";
                         area.setText(total);
                          }
                   }
                         else
                         JOptionPane.showMessageDialog(null,"Empty area!");
           }
       });
        studentappearance=new JMenuItem("STUDENT APPEARANCE");
        studentappearance.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                 int z=Integer.parseInt(JOptionPane.showInputDialog("GIVE ID"));
                          boolean found=false;
                          for(Student a : mstudents)//διατρεχω την λιστα mstudents
                          {
                              if (a.getStudid()== z )//ελέγχω εαν το id που εδωσε ο χρηστης υπαρχει στη λιστα mstudents αν υπαρει μπαινω αν οχι δεν μπαινω
                                      {
                                          found=true;
                                          break;
                                      }
                          }                       
                          if(found)
                                  {
                             String total="";
                             String total2="";
                             double total3=0;
                             double mo=0.0;
                             int c=0;     
                           for(Student a:mstudents)//διατρέχει την λίστα menrolls και tis ekswrei sto total
                              if(a.getStudid()==z)
                               total+=a+"\n";
                           for(Enroll l:menrolls)//διατρέχει την λίστα menrolls καιεκτυπώνει τις εγγραφές
                           {  if(l.getStudentcode()==z){
                              total2+=l+"\n";//prosthetei sto total2 th sykekrimenh eggrafh pou exei vrethei to id
                              c++;//ean brei to sugkekrimeno id sth dhlwsh tote auksanei kata mia monada to metrhth....dld to c einai o arithmos twn dhlwsewn pou yparxei to id auto
                              total3+=l.getStudgrade();//pairnei ton bathmo pou exei sth sygkekrimenh dhlwsh o mathitis
                            }}
                           mo=(total3)/c;
                           area.setText(total+total2+mo);
                                  }
                           else
                           JOptionPane.showMessageDialog(null,"false!");
           }
        });
        studentdeletion=new JMenuItem("STUDENT DELETION");
        studentdeletion.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                 int z=Integer.parseInt(JOptionPane.showInputDialog("GIVE student id"));
                        
                          for(int i=0 ; i<mstudents.size(); i++)//διατρεχω την λιστα mlessons
                          {
                              if (mstudents.get(i).getStudid()== z )//ελέγχω εαν O CODE που εδωσε ο χρηστης υπαρχει στη λιστα mstudents αν υπαρει μπαινω αν οχι δεν μπαινω
                                      {
                                          mstudents.remove(mstudents.get(i));
                                      }
                          }
                          Iterator<Enroll>en=menrolls.iterator();
                          while(en.hasNext())
                          {
                              if(en.next().getStudentcode()==z)//ελεγχει αν υπαρχει ήδη μια εγγραφή ωστε να μην την ξαναβάλει getstudentcode==
                              en.remove();  // diagrafw mono thn eggrafh tou mathiti z
                          
                          }
                           String total="";
                           for(Student a:mstudents)//διατρέχει την λίστα mstudents καιεκτυπώνει τις εγγραφές
                              total+=a+"\n";
                           for(Enroll l:menrolls)//διατρέχει την λίστα menrolls καιεκτυπώνει τις εγγραφές
                              total+=l+"\n";
                           area.setText(total);
          }
        });
        filestudent.add(newstudent);//βάζει στο menustudent τα menuitems newstudents lessonenrollments etc
        filestudent.add(lessonenrollment);
        filestudent.add(studentappearance);
        filestudent.add(studentdeletion);
        menubar.add(filestudent);
        
        newlesson=new JMenuItem("NEW LESSON");
        newlesson.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                firstinputdialoglesson ls=new firstinputdialoglesson(StudentFrame.this);
                System.out.println("pressed NEW LESSON");
                Lesson mylesson=ls.getLesson();//ΔΗΜΙΟΥΡΓΙΑ ΑΝΤΙΚΕΙΜΕΝΟΥ ΠΟΥ ΚΑΛΩ ΑΠΟ ΤΗ ΚΛΑΣΣΗ FIRSTINPUTDIALOGlesson kai create an obgect named lesson me onma mylesson
                if(mylesson.getLesname().length()!=0 || mylesson.getLescode()!=0 || mylesson.getSemester()!=0)//ελεγχει το μηκος των πεδίων
                  {
                    boolean found=false;
                          for(Lesson a : mlessons)//EINAI ΓΙΑ ΨΑΞΙΜΟ
                          {
                              if (a.getLesname()== mylesson.getLesname())//EAN TO ANTIKEIMENO EINAI MESA STH LISTA KANEI TO KWDIKA FOUND TRUE KAI BGAINEI ME TO BREAK
                                      {
                                          found=true;
                                          break;
                                      }
                          }
                          if(found)
                          JOptionPane.showMessageDialog(null,"Already there");
                          else 
                             mlessons.add(mylesson);// ASSIGN OBJECT INTO LIST
                          String total="";
                          for (Lesson a:mlessons)//ΕΙΝΑΙ ΓΙΑ ΕΚΤΥΠΩΣΗ
                          {
                          total+=a+"\n";
                           }//running the list and add the objects to the alphanumeric 
                          area.setText(total);
                         }
                         else
                          JOptionPane.showMessageDialog(null,"Empty area!");
            }
        });
        performanceappearance=new JMenuItem("PERFORMANCE APPEARANCE");      
        performanceappearance.addActionListener(new ActionListener()
        {
             @Override
            public void actionPerformed(ActionEvent ae)
            {
                 int z=Integer.parseInt(JOptionPane.showInputDialog("GIVE COURSE ID"));
                          boolean found=false;
                          String total="";
                          String total2="";
                          String total3="";
                          for(Lesson a : mlessons)//διατρεχω την λιστα mlessons
                          {
                              if (a.getLescode()== z )//ελέγχω εαν το id που εδωσε ο χρηστης υπαρχει στη λιστα mstudents αν υπαρει μπαινω αν οχι δεν μπαινω
                                      {
                                          total2=a.getLescode()+"\n";
                                          found=true;
                                          break;
                                      }
                          }
                         if(found)
                                  {
                           for(Enroll l:menrolls)//διατρέχει την λίστα menrolls καιεκτυπώνει τις εγγραφές
                           {
                               if(l.getCoursecode()==z){
                                     total+=l.getStudentcode()+l.getStudgrade()+"\n";//emfanizei tis dhlwseis gia to sygkekrimeno id pou edwse o xrhsths
                               }
                           }
                           total3=total+total2;
                           area.setText(total3);
                                  }
                           else
                           JOptionPane.showMessageDialog(null,"false!");
                                  
            }});
        semesterselection=new JMenuItem("SEMESTER SELECTION");
        semesterselection.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                int z=Integer.parseInt(JOptionPane.showInputDialog("GIVE SEMESTER"));
                          boolean found=false;
                          for(Lesson a : mlessons)//διατρεχω την λιστα mlessons
                          {
                              if (a.getSemester()== z )//ελέγχω εαν το semester που εδωσε ο χρηστης υπαρχει στη λιστα mlessons αν υπαρxει μπαινω αν οχι δεν μπαινω
                                      {
                                          found=true;
                                          break;
                                      }
                          }
                          if(found)
                            {
                           String total="";
                           for(Lesson a:mlessons)//διατρέχει την λίστα mlessons καιεκτυπώνει τις εγγραφές
                           {
                             if(a.getSemester()==z) total+=a+"\n";}
                              area.setText(total);
                           }
                           else
                           JOptionPane.showMessageDialog(null,"false!");
          } });
        lessondeletion=new JMenuItem("LESSON DELETION"); 
        lessondeletion.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                 int z=Integer.parseInt(JOptionPane.showInputDialog("GIVE COURSE CODE"));
                          boolean found=false;
                          boolean found2=false;
                          for(int i=0 ; i<mlessons.size(); i++)//διατρεχω την λιστα mlessons
                          {
                              if (mlessons.get(i).getLescode()== z )//ελέγχω εαν O CODE που εδωσε ο χρηστης υπαρχει στη λιστα mlessons αν υπαρει μπαινω αν οχι δεν μπαινω
                                      {
                                          found=true;
                                          mlessons.remove(mlessons.get(i));
                                      }
                          }
                        for(int x=0 ; x<menrolls.size(); x++)//διατρέχουμε την λίστα mentrolls
                          {
                              if(menrolls.get(x).getCoursecode()==z)//ελεγχει αν υπαρχει ήδη μια εγγραφή ωστε να μην την ξαναβάλει
                              found2=true;
                             menrolls.remove(menrolls.get(x));//DIAGRAFW EGGRAFH
                          }
                             String total="";
                           for(Lesson a:mlessons)//διατρέχει την λίστα mlessons καιεκτυπώνει τις εγγραφές
                              total+=a+"\n";
                           for(Enroll l:menrolls)//διατρέχει την λίστα menrolls καιεκτυπώνει τις εγγραφές
                              total+=l+"\n";
                           area.setText(total);
                 } });
        filelesson.add(newlesson);//βάζει στο menulesson τα menuitems newlesson performance appearence etc
        filelesson.add(performanceappearance);
        filelesson.add(semesterselection);
        filelesson.add(lessondeletion);
        menubar.add(filelesson);
        
        bt=new JButton("hello");
        add(bt);
         area.setEditable(false);
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//when press x the window close
         setVisible(true);//up window=seems,down window=not seems
   } }
      
