/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia.tsoulos;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class firstinputdialoglesson extends JDialog{
    private JTextField nameText,IDText,semesterText;
    private JButton okButton,cancelButton;
    private JPanel panel1,panel2;
    public Lesson getLesson()
    {
       Lesson ls=new Lesson();
       ls.setLesname(nameText.getText());
       ls. setLescode(Integer.parseInt(IDText.getText()));//convert alphanumeric into string
       ls.setSemester(Integer.parseInt(semesterText.getText()));
       return ls;
    }
    void makePanel1()
    {
    
       panel1=new JPanel();
       panel1.setLayout(new GridLayout(1,8));//αυστηρη διαταξη
       panel1.add(new JLabel("NAME: "));
       nameText=new JTextField(" ",15);
       panel1.add(nameText);
       panel1.add(new JLabel("ID: "));
       IDText=new JTextField("0",15);
       panel1.add(IDText);
       panel1.add(new JLabel("SEMESTER: "));
       semesterText=new JTextField("",15);
       panel1.add(semesterText);
       add(panel1);
    }
    void makePanel2()
    {
        panel2=new JPanel();
        panel2.setLayout(new GridLayout(1,2));
        okButton=new JButton("ADD LESSON");
        panel2.add(okButton);
        okButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                  setVisible(false);
                  dispose();// vanish the dialog
            }
            
        });
        cancelButton=new JButton("CANCEL");
        panel2.add(cancelButton);
         cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                IDText.setText("");
                setVisible(false);
                  dispose();// couses the JFrame window to be destroyed and cleaned up by the operating system
            }
            
        });
        add(panel2);
    }
    public firstinputdialoglesson(JFrame parent)
    {
        super(parent,"Input dialog");
       
        this.setModal(true);//KANEI APOKLEISTIKO TO DIALOGO DLD DEN MPORW NA ANOIKW ALLO FIRSTINPUTDIALOG PANW SE ALLO FRAME
        setLayout(new GridLayout(2,1));
        setSize(600,100);
        setResizable(false);
        makePanel1();
        makePanel2();
        setVisible(true);
    }
}
    
    

