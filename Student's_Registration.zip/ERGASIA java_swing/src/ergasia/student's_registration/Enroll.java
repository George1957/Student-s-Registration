/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia.tsoulos;

public class Enroll {
    
    private int studentcode,coursecode,studgrade;
    
    public Enroll()
    {
        studentcode = 0;
        coursecode = 0;
        studgrade = 0;
    }
    public Enroll(int stcode,int crcode,int stg)
    {
        studentcode = stcode;
        coursecode= crcode;
        studgrade=stg;
        if(stcode>0)
            studentcode = stcode;
        if (crcode>0)
            coursecode = crcode;
        if (stg>0)
            studgrade=stg;
    }        
    public int getStudentcode(){return studentcode;}
    public int getCoursecode(){return coursecode;}
    public int getStudgrade(){return studgrade;}
    
    public void setStudentcode(int stcode){studentcode=stcode;}
    public void setCoursecode(int crcode){coursecode=crcode;}
    public void setStudgrade(int stg){studgrade =stg;}
    
    
    @Override
    public String toString()
    {
        return "Studentcode : "+studentcode+" Coursecode: "+coursecode+" studgrade:"+studgrade;
    }
    
}
