/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia.tsoulos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
public class firstinputdialogenrolls extends JDialog{
    private JTextField studcodeText,coursecodeText,studgradeText;
    private JButton okButton,cancelButton;
    private JPanel panel1,panel2;
    public Enroll getEnroll()
    {
       Enroll en=new Enroll();//DHMIOURGW ENA ANTIKEIMENO KAI PERNAV TIS EKASTOTE TIMES TOU
       en.setStudentcode(Integer.parseInt(studcodeText.getText()));
       en.setCoursecode(Integer.parseInt(coursecodeText.getText()));//convert alphanumeric into string
       en.setStudgrade(Integer.parseInt(studgradeText.getText()));
       return en;
    }
    void makePanel1()
    {
       panel1=new JPanel();
       panel1.setLayout(new GridLayout(1,6));
       panel1.add(new JLabel("STUDENT CODE: "));
       studcodeText=new JTextField("",15);
       panel1.add( studcodeText);
       panel1.add(new JLabel("COURSE CODE: "));
       coursecodeText=new JTextField("",15);
       panel1.add(coursecodeText);
       panel1.add(new JLabel("STUDENT GRADE: "));
       studgradeText=new JTextField("",15);
       panel1.add(studgradeText);
       add(panel1);
    }
    void makePanel2()
    {
        panel2=new JPanel();
        panel2.setLayout(new GridLayout(1,2));
        okButton=new JButton("ADD ENROLLMENT");
        panel2.add(okButton);
        okButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                  setVisible(false);
                  dispose();// vanish the dialog
            }
            
        });
        cancelButton=new JButton("CANCEL");
        panel2.add(cancelButton);
         cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                coursecodeText.setText("");
                setVisible(false);
                  dispose();// causes the JFrame window to be destroyed and cleaned up by the operating system
            }
            
        });
        add(panel2);
    }
    public firstinputdialogenrolls(JFrame parent)
    {
        super(parent,"Input dialog");
       
        this.setModal(true);//KANEI APOKLEISTIKO TO DIALOGO DLD DEN MPORW NA ANOIKsW ALLO FIRSTINPUTDIALOG PANW SE ALLO FRAME
        setLayout(new GridLayout(2,1));
        setSize(600,100);
        setResizable(false);
        makePanel1();
        makePanel2();
        setVisible(true);
    }
}
    

