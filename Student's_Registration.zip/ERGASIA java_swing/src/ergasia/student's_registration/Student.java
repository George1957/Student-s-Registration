/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia.tsoulos;

public class Student {
    private String name,lastname;
    private int studid,semester;
    
    public Student()
    {
        name = "";
        lastname = "";
        studid = 0;
        semester = 0;
    }
    public Student(String n,String ln,int si,int s)
    {
        name = n;
        lastname= ln;
        if(si>0)
            studid = si;
        if (s>0)
            semester = s;
    }        
    public String getName(){return name;}
    public String getLastName(){return lastname;}
    public int getStudid(){return studid;}
    public int getSemester(){return semester;}
    
    public void setName(String n){name=n;}
    public void setLastName(String ln){lastname =ln;}
    public void setStudid(int si){studid=si;}
    public void setSemester(int s){semester =s;}
    
    
    @Override
    public String toString()
    {
        return "Name : "+name+" Lastname : "+lastname+" Studid: "+studid+" semester: "+semester;
    }
    
}
