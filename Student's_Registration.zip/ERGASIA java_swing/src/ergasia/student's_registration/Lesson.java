/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ergasia.tsoulos;


public class Lesson {
    private String lesname;
    private int lescode,semester;
    
    public Lesson()
    {
        lesname = "";
        lescode = 0;
        semester = 0;
    }
    public Lesson(String lesn,int lesc,int s)
    {
        lesname = lesn;
        lescode= lesc;
        if(lesc>0)
            lescode = lesc;
        if (s>0)
            semester = s;
    }        
    public String getLesname(){return lesname;}
    public int getLescode(){return lescode;}
    public int getSemester(){return semester;}
    
    public void setLesname(String lesn){lesname=lesn;}
    public void setLescode(int lesc){lescode=lesc;}
    public void setSemester(int s){semester =s;}
    
    
    @Override
    public String toString()
    {
        return "Lesname : "+lesname+" Lescode: "+lescode+" semester: "+semester;
    }
    
}


