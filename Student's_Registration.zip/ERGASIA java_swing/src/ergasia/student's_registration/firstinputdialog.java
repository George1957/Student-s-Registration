
package ergasia.tsoulos;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class firstinputdialog extends JDialog {
    private JTextField nameText,lastnameText,IDText,semesterText;
    private JButton okButton,cancelButton;
    private JPanel panel1,panel2;
    
    public Student getStudent()
    {
       Student s=new Student();
       s.setName(nameText.getText());
       s.setLastName(lastnameText.getText());
       s.setStudid(Integer.parseInt(IDText.getText()));//convert alphanumeric into string
       s.setSemester(Integer.parseInt(semesterText.getText()));
       return s;
    }
    void makePanel1()
    {
       panel1=new JPanel();//mia aneksarthth perioxh sto parathuro...dld ena aneksarthto layout
       panel1.setLayout(new GridLayout(1,8));
       panel1.add(new JLabel("NAME: "));
       nameText=new JTextField(" ",15);
       panel1.add(nameText);
       panel1.add(new JLabel("LASTNAME: "));
       lastnameText=new JTextField(" ",15);
       panel1.add(lastnameText);
       panel1.add(new JLabel("ID: "));
       IDText=new JTextField("0",15);
       panel1.add(IDText);
       panel1.add(new JLabel("SEMESTER: "));
       semesterText=new JTextField("",15);
       panel1.add(semesterText);
       add(panel1);
    }
    void makePanel2()
    {
        panel2=new JPanel();
        panel2.setLayout(new GridLayout(1,2));
        okButton=new JButton("ADD STUDENT");
        panel2.add(okButton);
        okButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                  setVisible(false);//xrhsimopoieitai an thelw na balw times dld na ekxwrhsw pragmata
                  dispose();// vanish the dialog
            }
            
        });
        cancelButton=new JButton("CANCEL");
        panel2.add(cancelButton);
         cancelButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                IDText.setText("");
                setVisible(false);
                  dispose();// vanish the dialog
            }
            
        });
        add(panel2);
    }
    public firstinputdialog(JFrame parent)
    {
        super(parent,"Input dialog");//deikths pou anaferetai kai pairnei san parametroys to parent kai to input dialog opou to parent einai to student frame kai to input einai to onoma pou exei to parathuro auto
       
        this.setModal(true);//KANEI APOKLEISTIKO TO DIALOGO DLD DEN MPORW NA ANOIKW ALLO FIRSTINPUTDIALOG PANW SE ALLO FRAME
        setLayout(new GridLayout(2,1));
        setSize(600,100);
        setResizable(false);
        makePanel1();
        makePanel2();
        setVisible(true);
    }
}
